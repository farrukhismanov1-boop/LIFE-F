# LIFE F

Personal AI operating system — iOS-first MVP.

## Repository layout
- `mobile/`: Flutter iOS client starter.
- `backend/`: FastAPI service, SQLAlchemy models, task API, AI chat API.
- `docs/`: architecture, database, and API notes.

## Backend quick start
1. Install Python 3.11+.
2. `cd backend`
3. Create a virtual environment: `python -m venv .venv`
4. Activate it, then install: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env`.
6. Set `OPENAI_API_KEY` and `OPENAI_MODEL` to a model available to your API account.
7. Run: `uvicorn app.main:app --reload`
8. Open `http://127.0.0.1:8000/docs`.

The task API and health check can run without an AI key. Chat requires the AI key and model.

## Mobile quick start
1. Install Flutter and Xcode on macOS.
2. `cd mobile`
3. `flutter pub get`
4. `flutter run` (select an iOS simulator or connected iPhone).

## Important MVP limitations
- Authentication is not implemented yet. API routes currently use a temporary development user ID and are for local single-user testing only.
- Do not expose this backend publicly until authentication, authorization, migrations, rate limiting, HTTPS, and production configuration are implemented.
- Chat currently answers questions but does not execute AI-generated actions. Task APIs are separate and deterministic.
- The first screen is a UI scaffold; navigation and live API wiring are the next development step.
- Multilingual AI replies are requested through the assistant instructions. Full translated UI resources are not yet implemented.
