# LIFE F — Database

Core tables: users, profiles, conversations, messages, memories, projects, tasks, events, habits, activity_logs.

Relationships:
- users 1:1 profiles
- users 1:N conversations, memories, projects, tasks, events, habits, activity_logs
- conversations 1:N messages
- projects 1:N tasks (optional project association)

All user-owned records carry `user_id`. Production must enforce ownership in every query and add verified authentication before multi-user access. Timestamps should be stored in UTC; profile timezone controls display and scheduling.
