# LIFE F — API v1

Base path: `/api/v1`

| Method | Path | Purpose |
|---|---|---|
| POST | `/chat` | Send a message and receive an AI reply |
| GET | `/tasks` | List current user's tasks |
| POST | `/tasks` | Create a task |
| PATCH | `/tasks/{task_id}` | Update a task |
| DELETE | `/tasks/{task_id}` | Delete a task |

System endpoint: `GET /health`.

Interactive API documentation is available at `/docs` while the FastAPI server is running.

Future endpoints: `/projects`, `/events`, `/memories`, `/habits`, `/conversations`, `/profile`, `/actions/preview`, `/actions/confirm`.
