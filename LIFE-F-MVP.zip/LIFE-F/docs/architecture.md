# LIFE F — Architecture (MVP)

## Product boundaries
- iOS-first mobile client built with Flutter.
- FastAPI backend owns secrets, persistence, AI calls, and business rules.
- The mobile app never contains an AI provider API key.
- AI proposes actions; deterministic backend services validate and execute them. Destructive or externally visible actions require explicit user confirmation.

## MVP request flow
1. Flutter sends HTTPS request to `/api/v1/chat` or task endpoints.
2. FastAPI validates input and identifies the authenticated user (development currently uses a clearly marked temporary user ID).
3. Chat service stores the user message and calls the configured AI provider.
4. The assistant reply is stored and returned to the client.
5. Task operations are performed by backend code and persisted in the database.

## Deployment evolution
- Local development: SQLite.
- Hosted MVP: managed PostgreSQL, HTTPS, secret manager, verified authentication, database migrations, backups, rate limiting, and monitoring.
- Do not deploy the development identity stub to production.
