import 'package:flutter/material.dart';

class LifeFApp extends StatelessWidget {
  const LifeFApp({super.key});

  @override
  Widget build(BuildContext context) {
    const ivory = Color(0xFFF4F0E8);
    const gold = Color(0xFFC6A15B);
    return MaterialApp(
      title: 'LIFE F',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0B0B),
        colorScheme: const ColorScheme.dark(
          primary: gold,
          surface: Color(0xFF151515),
          onSurface: ivory,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LIFE F', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.w700)),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.account_circle_outlined))],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 18),
            Text('YOUR PERSONAL INTELLIGENCE', style: TextStyle(color: Theme.of(context).colorScheme.primary, letterSpacing: 2, fontSize: 11)),
            const SizedBox(height: 12),
            const Text('Good evening.', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            const Text('What would you like to accomplish today?', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 28),
            _Panel(title: "Today's overview", child: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _Metric(value: '0', label: 'Tasks'),
                _Metric(value: '0', label: 'Projects'),
                _Metric(value: '0', label: 'Events'),
              ],
            )),
            const SizedBox(height: 16),
            _Panel(title: 'AI Assistant', child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Your assistant is ready. Connect the backend to start chatting.'),
                const SizedBox(height: 14),
                FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.chat_bubble_outline), label: const Text('Open assistant')),
              ],
            )),
            const SizedBox(height: 16),
            const _Panel(title: 'Quick access', child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _QuickAction(icon: Icons.check_circle_outline, label: 'Tasks'),
                _QuickAction(icon: Icons.calendar_month_outlined, label: 'Planner'),
                _QuickAction(icon: Icons.work_outline, label: 'Projects'),
                _QuickAction(icon: Icons.psychology_outlined, label: 'Memory'),
              ],
            )),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF151515),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Planner'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'AI'),
          NavigationDestination(icon: Icon(Icons.work_outline), label: 'Business'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({required this.title, required this.child});
  final String title;
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: const Color(0xFF151515), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white12)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
      const SizedBox(height: 16),
      child,
    ]),
  );
}

class _Metric extends StatelessWidget {
  const _Metric({required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600, color: Color(0xFFC6A15B))),
    Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
  ]);
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.label});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 17), label: Text(label));
}
