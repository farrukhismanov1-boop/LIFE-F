from openai import OpenAI
from app.config import settings


class AIConfigurationError(RuntimeError):
    pass


def generate_reply(user_message: str, language: str = "auto") -> str:
    """Call the configured model. API keys remain on the server, never in the app."""
    if not settings.openai_api_key or not settings.openai_model:
        raise AIConfigurationError("Configure OPENAI_API_KEY and OPENAI_MODEL in backend/.env")

    client = OpenAI(api_key=settings.openai_api_key)
    response = client.responses.create(
        model=settings.openai_model,
        instructions=(
            "You are LIFE F, a practical multilingual personal assistant. "
            "Reply in the user's language unless they request another language. "
            "Be concise, distinguish facts from uncertainty, and never claim an action "
            "was completed unless a tool or application confirms it. Do not execute "
            "external actions from chat in this MVP; provide a proposed action instead."
        ),
        input=user_message,
    )
    return response.output_text
