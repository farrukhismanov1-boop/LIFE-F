from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    conversation_id: int | None = None
    language: str = "auto"


class ChatResponse(BaseModel):
    conversation_id: int
    message: str
    provider: str
