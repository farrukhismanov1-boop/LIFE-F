from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.ai.provider import AIConfigurationError, generate_reply
from app.database import get_db
from app.models.entities import Conversation, Message
from app.schemas.chat import ChatRequest, ChatResponse

router = APIRouter(prefix="/chat", tags=["assistant"])
DEV_USER_ID = 1


@router.post("", response_model=ChatResponse)
def chat(payload: ChatRequest, db: Session = Depends(get_db)):
    conversation = None
    if payload.conversation_id is not None:
        conversation = db.query(Conversation).filter(
            Conversation.id == payload.conversation_id,
            Conversation.user_id == DEV_USER_ID,
        ).first()
        if conversation is None:
            raise HTTPException(status_code=404, detail="Conversation not found")
    else:
        conversation = Conversation(user_id=DEV_USER_ID)
        db.add(conversation)
        db.commit()
        db.refresh(conversation)

    db.add(Message(conversation_id=conversation.id, role="user", content=payload.message))
    db.commit()
    try:
        reply = generate_reply(payload.message, payload.language)
    except AIConfigurationError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="AI provider request failed") from exc

    db.add(Message(conversation_id=conversation.id, role="assistant", content=reply))
    db.commit()
    return ChatResponse(conversation_id=conversation.id, message=reply, provider="openai")
